/* Javascript Document */

function readyMenu(){
	$(".main_menu a").click(function(){
		var menuAsociado = '#menu_' + $(this).attr('rel');
			if ($(menuAsociado).length > 0){
				var menuActivo = '#menu_' + $('.active').attr('rel');
					if (menuAsociado != menuActivo){
						$('.sec_menu').hide( 75 )
						$('.main_menu a').removeClass( 'active' );
						$(menuAsociado).show( 75 );
						$(this).addClass( 'active' );
					}
			}
		});
}

function readyFilterPopup(){
	$('.filters > li > a').click(function(){
			$( this ).parent().children( '.filter_box' ).fadeIn( 200 );
		});
	$('.filters .filter_box input').click(function(){
			var newFilterParameter = $( this ).attr( 'title' );
				$( this ).parents( '.filter_box' ).parent().children( '.activeFiltering' ).children( 'span' ).text( newFilterParameter );
			var container_box = $( this ).parents( '.filter_box' );
				$( this ).parents( '.filter_box' ).fadeOut( 200 );
		});
}

function readyDropdownText(){
	$( '.answerText' ).hide( 75 );
	$( 'h2 + span' ).hide( 75 );
	
	$('h2 a').click(function(){
			if( $( this ).hasClass( 'opened' ) ){
				$( this ).parent().next().fadeOut( 200 );
				$( this ).removeClass( 'opened' );
			}else{
				$( this ).parent().next().fadeIn( 200 );
				$( this ).addClass( 'opened' );
			}
			
		});
	$('h3 a').click(function(){
			if( $( this ).hasClass( 'opened' ) ){
				$( this ).parent().next(  ).fadeOut( 200 );
				$( this ).removeClass( 'opened' );
			}else{
				$( this ).parent().next(  ).fadeIn( 200 );
				$( this ).addClass( 'opened' );
			}
			
		});
	$('.answerText .btn_close').click(function(){
			$( this ).parents( '.answerText' ).fadeOut( 200 );
			$( this ).parents( '.answerText' ).prev().find( '.opened' ).removeClass( 'opened' );
		});
}

function readyTabbedProductInfor(){
	$( '.product_tabed_titles a' ).click(function(){
			var tabClicked = $( this ).attr( 'rel' );
			var tabActive = $( '.product_tabed_titles' ).children( '.active' ).find( 'a' ).attr( 'rel' );
				$( '.product_tabed_titles li' ).removeClass( 'active' );
				$( this ).parents( 'li' ).addClass( 'active' );
				$( '#'+tabActive ).fadeOut( 75 );
				$( '#'+tabClicked ).fadeIn( 200 );
				return false
		});
}